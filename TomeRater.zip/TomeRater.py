# Definition: User class
class User(object):

# Constructor: User class
    def __init__(self, name, email):
        self.name = name
        self.email = email
        self.book = {}

# This method gets e-mail address of user
    def get_email(self):
        return self.email

# This method changes e-mail address of user
    def change_email(self, address):
        self.ce_address = address
        old_email = self.email

        self.email = self.ce_address
        print("Email address for {usr} has been updated from {oemail} to {nemail}".format(usr=self.name, oemail=old_email, nemail=self.email))

# This method prints user name, e-mail and books read
    def __repr__(self):
        return "User: {usr}, E-mail: {eadr}, Book Ratings: {brn}".format(usr=self.name, eadr=self.email, brn=self.book)

# This method check if user name is equal
    def __eq__(self, other_user):
        self.eq_other_user = other_user
        if (self.name == self.eq_other_user.name and self.email == self.eq_other_user.email):
            return True
        else:
            return False

# This method adds the recently read books and rating for User 
    def read_book(self, recent_book, rating=None):
        self.rb_recently_read_book = recent_book
        self.rb_rating = rating
        if self.rb_rating is None:
            self.book[self.rb_recently_read_book] = 0
        else:
            self.book[self.rb_recently_read_book] = self.rb_rating

# This method calculates average rating of books read by the user
    def get_average_rating(self):
        gar_total_ratings = 0
        gar_average_rating = 0
        for v in self.book.values():
            gar_total_ratings += v
        gar_average_rating = gar_total_ratings / len(self.book)
        return gar_average_rating


# Definition: Book class
class Book():

# Constructor: Book class
    def __init__(self, title, isbn):
        self.title = title
        self.isbn = isbn
        self.ratings = []

# This method gets the book title
    def get_title(self):
        return self.title

# This method gets the book isbn no.
    def get_isbn(self):
        return self.isbn

# This method changes book's isbn no.
    def set_isbn(self, new_isbn):

        self.sb_new_isbn = new_isbn
        sb_old_isbn = self.isbn

        self.isbn = self.sb_new_isbn
        print("ISBN for {ttl} has been updated from {oisbn} to {nisbn}".format(ttl=self.title, oisbn=sb_old_isbn, nisbn=self.isbn))

# This method adds book rating
    def add_rating(self, rating_value):

        try:
            self.ar_rating_value = rating_value

            if self.ar_rating_value < 0 or self.ar_rating_value > 4:
                print("Invalid Rating")
            else:
                self.ratings.append(self.ar_rating_value)
        except Exception as err:
            print("Book.add_rating() Method Exception {}".format(err))

# This method check is book title and isbn are equal to another book
    def __eq__(self, other_book):
        self.eq_other_book = other_book
        if (self.title == self.eq_other_book.title and self.isbn == self.eq_other_book.isbn):
            return True
        else:
            return False


# This method calculates average rating of books
    def get_average_rating(self):
        garb_total_ratings = 0
        garb_average_rating = 0
        for i in range(0, len(self.ratings)):
            garb_total_ratings += self.ratings[i] 
        garb_average_rating = garb_total_ratings / len(self.ratings)
        return garb_average_rating

# To make the book object hashable and return consistent hash of the instance
    def __hash__(self):
       return hash((self.title, self.isbn))

# This method returns book title
    def __repr__(self):
        return "Book: {ttl}".format(ttl=self.title)


# Definition: Fiction class
class Fiction(Book):

# Constructor: Ficntion class
    def __init__(self, title, author, isbn):
        super().__init__(title, isbn)
        self.author = author

# This method gets the author
    def get_author(self):
        return self.author

# This method returns book by author
    def __repr__(self):
        return "Book: {ttl} by Author: {athr}".format(ttl=self.title, athr=self.author)

# Definition: Non_Fiction class
class Non_Fiction(Book):

# Constructor: Non_Ficntion class
    def __init__(self, title, subject, level, isbn):
        super().__init__(title, isbn)
        self.subject = subject
        self.level = level

# This method gets book sobject
    def get_subject(self):
        return self.subject

# This method gets book level
    def get_level(self):
        return self.level

# This method returns book title, level and subject
    def __repr__(self):
        return "Book: {ttl}, a {lvl} manual on {sbj}".format(ttl=self.title, lvl=self.level, sbj={self.subject})


# Definition: TomeRater class
class TomeRater():

# Constructor: TomeRater class
    def __init__(self):
        self.users = {}
        self.books = {}
        self.book_isbn = []

# This method creates book
# Method will check for unique ISBN before creating the book
    def create_book(self, title, isbn):
        self.cb_title = title
        self.cb_isbn = isbn
        if self.check_unique_isbn(self.cb_isbn) is True:
            regular_book = Book(self.cb_title, self.cb_isbn)
            self.book_isbn.append(self.cb_isbn)
            return regular_book
        else:
            return print("Book: {bk} not created. Duplicate ISBN: {sbn}.".format(bk=self.cb_title, sbn=self.cb_isbn))

# This method creates finction book
# Method will check for unique ISBN before creating the book
    def create_novel(self, title, author, isbn):
        self.fb_title = title
        self.fb_isbn = isbn
        self.fb_author = author
        if self.check_unique_isbn(self.fb_isbn) is True:
            fiction_book = Fiction(self.fb_title, self.fb_author, self.fb_isbn)
            self.book_isbn.append(self.fb_isbn)
            return fiction_book
        else:
            return print("Book: {bk} not created. Duplicate ISBN: {sbn}.".format(bk= self.fb_title, sbn=self.fb_isbn))

# This method creates non-finction book
# Method will check for unique ISBN before creating the book
    def create_non_fiction(self, title, subject, level, isbn):
        self.nfb_title = title
        self.nfb_isbn = isbn
        self.nfb_subject = subject
        self.nfb_level = level
        if self.check_unique_isbn(self.nfb_isbn) is True:
            non_fiction_book = Non_Fiction(self.nfb_title, self.nfb_subject, self.nfb_level, self.nfb_isbn)
            self.book_isbn.append(self.nfb_isbn)
            return non_fiction_book
        else:
            return print("Book: {bk} not created. Duplicate ISBN: {sbn}.".format(bk=self.nfb_title, sbn=self.nfb_isbn))

# Method to check if the ISBN is unique
    def check_unique_isbn(self, isbn):
        self.cui_isbn = isbn
        if len(self.book_isbn) > 0:
            for i in range(0, len(self.book_isbn)):
                if self.book_isbn[i] == self.cui_isbn:
                    return False
        return True

# This method adds the user
# Before adding the user check that e-mail is not used by another user 
# add User
# add the book from user_books using method add_book_to_user 
    def add_user(self, name, email, user_books=None):
        self.au_name = name
        self.au_email = email
        self.au_user_books = user_books

        if self.validate_email_format(self.au_email) is False:
            return print("User: {usr} not added. Email id: {eml} has invalid format".format(eml=self.au_email, usr=self.au_name))

        if self.check_email_used(self.au_email) is True:
            return print("User: {usr} not added. Email id: {eml} already used by another user.".format(eml=self.au_email, usr=self.au_name))

        new_user = User(self.au_name, self.au_email)
        self.users[self.au_email] = new_user

        if self.au_user_books is not None:
            for i in range(0, len(self.au_user_books)):
                self.add_book_to_user(self.au_user_books[i], self.au_email)
            
# Method to check if the E-mail is already used by another user
    def validate_email_format(self, email):
        self.cef_email = email

        email_has_ampersand = False
        email_has_domain = False

        for i in range(0, len(self.cef_email)):
            if self.cef_email[i] == "@":
                email_has_ampersand = True
                break

        if self.cef_email[-4:] == ".com" or self.cef_email[-4:] == ".edu" or self.cef_email[-4:] == ".org":
            email_has_domain = True

        if email_has_ampersand is True and email_has_domain is True:
            return True
        else:
            return False            

# Method to check if the E-mail is already used by another user
    def check_email_used(self, email):
        self.ceu_email = email
        if len(self.users) > 0:
            for k in self.users:
                if k == self.ceu_email:
                    return True
        return False

# This method adds book to user
# if user exists then call read_book and add_rating methods
# if book already exists then increate self.book value by 1 else set self.book value to 1

    def add_book_to_user(self, book, email, rating=None):
        self.abu_book_for_user = book
        self.abu_email_for_user = email
        self.abu_user_rating_for_book = rating
        try:
            self.abu_this_user = self.users[self.abu_email_for_user]

            self.abu_this_user.read_book(self.abu_book_for_user, self.abu_user_rating_for_book)

            if self.abu_user_rating_for_book is not None:
                self.abu_book_for_user.add_rating(self.abu_user_rating_for_book)

            try:
                self.books[self.abu_book_for_user] += 1
            except KeyError:
                self.books[self.abu_book_for_user] = 1

        except KeyError:
            print("No user with e-mail address: {eml}".format(eml=self.abu_email_for_user))

# This method prints the books catalog
    def print_catalog(self):
        print(" ")
        print("********** Book Catalog **********")
        for k, v in self.books.items():
            if v > 1:
                print(str(k), " | ", v, " users read it!")
            else:
                print(str(k), " | ", v, " user read it!")


# This method prints users
    def print_users(self):
        print(" ")
        print("********** User Catalog **********")
        print(" ")
        for i in self.users:
            print(self.users[i])
            print(" ")

# This method returns the most read books
    def most_read_book(self):
        mrb_most_read_book_key = " "
        mrb_most_read_book_value = 0
        for k, v in self.books.items():
            if v > mrb_most_read_book_value:
                mrb_most_read_book_value = v
                mrb_most_read_book_key = k
        return mrb_most_read_book_key

# This method returns the highest rated book
    def highest_rated_book(self):
        hrb_average_book_rating_value = 0
        hrb_current_highest = 0
        hrb_highest_rated_book_key = ""
        for k in self.books:
            hrb_average_book_rating_value = k.get_average_rating()
            if hrb_average_book_rating_value > hrb_current_highest:
                hrb_current_highest = hrb_average_book_rating_value
                hrb_highest_rated_book_key = k
        return hrb_highest_rated_book_key

# This method returns the most positive user
    def most_positive_user(self):
        mpu_average_positive_user_value = 0
        mpu_current_positive_user = 0
        mpu_positive_user_key = ""
        for v in self.users.values():
            mpu_average_positive_user_value = v.get_average_rating()
            if mpu_average_positive_user_value > mpu_current_positive_user:
                mpu_current_positive_user = mpu_average_positive_user_value
                mpu_positive_user_key = v
        return mpu_positive_user_key
